//
//  SnapChatInputApp.swift
//  SnapChatInput
//
//  Created by Gaurang on 19/04/22.
//

import SwiftUI

@main
struct SnapChatInputApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
         //   AppTabBarView()
        }
    }
}
